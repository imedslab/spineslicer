#Slicer Imports
import slicer
from slicer.i18n import tr as _
from slicer.i18n import translate
from slicer.ScriptedLoadableModule import *
from slicer.util import VTKObservationMixin
from slicer.parameterNodeWrapper import (
    parameterNodeWrapper,
    WithinRange,
)
from slicer import vtkMRMLScalarVolumeNode

#Required Imports
import logging
import os
from typing import Annotated, Optional
import numpy as np
import time
from datetime import datetime
import vtk
import platform
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)


#Install Dependencies
try:
    import matplotlib.pyplot as plt
    import segmentation_models_pytorch
    import albumentations
    import torch
    import pathlib
    import cv2
    import base64
    import torchvision
    import shapely
    import requests 
    print("All dependencies met...")
except:    
    libraries=['matplotlib','segmentation-models-pytorch','albumentations','torch','opencv-python','torchvision','shapely']
    libcount=len(libraries)
    progressbar = slicer.util.createProgressDialog(parent=None, value=0, maximum=100,windowTitle="Installing Dependencies",autoClose=True)
    progressbar.setMinimumWidth(390)

    count=0
    for lib in libraries:
        count+=1
        progressbar.labelText = f'Installing {count}/{libcount} dependencies'
        perc=round((count)*100/libcount,0)
        slicer.util.pip_install([lib])
        slicer.app.processEvents()
        progressbar.setValue(perc)

#
# DeepLS
#
class DeepLS(ScriptedLoadableModule):
    """Uses ScriptedLoadableModule base class, available at:
    https://github.com/Slicer/Slicer/blob/main/Base/Python/slicer/ScriptedLoadableModule.py
    """

    def __init__(self, parent):
        ScriptedLoadableModule.__init__(self, parent)
        self.parent.title = _("DeepSpine")  
        self.parent.categories = [translate("qSlicerAbstractCoreModule", "Lumbar Spine")]
        self.parent.dependencies = []  
        self.parent.contributors = ["Nash Kowlagi (University of Oulu)"]  
        self.parent.helpText = _("""Auto Segmentation and Grading for Lumbar Spine""")
        self.parent.acknowledgementText = _("""This file was originally developed by Nash Kowlagi, University of Oulu""")

#
# DeepLSParameterNode
#
@parameterNodeWrapper
class DeepLSParameterNode:
    """
    The parameters needed by module.
    inputVolume - Volume to segment the lumbar spine
    """
    inputVolume: vtkMRMLScalarVolumeNode


#
# DeepLSWidget
#
class DeepLSWidget(ScriptedLoadableModuleWidget, VTKObservationMixin):
    """Uses ScriptedLoadableModuleWidget base class, available at:
    https://github.com/Slicer/Slicer/blob/main/Base/Python/slicer/ScriptedLoadableModule.py
    """

    #Set the custom layout to focus on the sagittal view
    def setCustomLayout(self) -> None:

        customLayout = """
        <layout type="vertical" split="true">
        <item splitSize="400">
        <view class="vtkMRMLSliceNode" singletontag="Yellow">
            <property name="orientation" action="default">Sagittal</property>
            <property name="viewlabel" action="default">Y</property>
            <property name="viewcolor" action="default">#EDD54C</property>
        </view>
        </item>
        <item splitSize="50">
        <view class="vtkMRMLTableViewNode" singletontag="T">
        <property name="viewlabel" action="default">T</property>
        </view>
        </item>
        </layout>
        """

        # Built-in layout IDs are all below 100, so you can choose any large random number
        # for your custom layout ID.
        customLayoutId=501
        layoutManager = slicer.app.layoutManager()
        layoutManager.layoutLogic().GetLayoutNode().AddLayoutDescription(customLayoutId, customLayout)

        # Switch to the new custom layout
        layoutManager.setLayout(customLayoutId)

    def __init__(self, parent=None) -> None:
        """Called when the user opens the module the first time and the widget is initialized."""
        ScriptedLoadableModuleWidget.__init__(self, parent)
        VTKObservationMixin.__init__(self)  # needed for parameter node observation
        self.segmentLS = None
        self.gradeLS=None
        self.processBatch=None
        self._parameterNode = None
        self._parameterNodeGuiTag = None
        self.setCustomLayout()

    def setup(self) -> None:
        """Called when the user opens the module the first time and the widget is initialized."""
        ScriptedLoadableModuleWidget.setup(self)

        # Load widget from .ui file (created by Qt Designer).
        # Additional widgets can be instantiated manually and added to self.layout.
        uiWidget = slicer.util.loadUI(self.resourcePath("UI/DeepLS.ui"))
        self.layout.addWidget(uiWidget)
        self.ui = slicer.util.childWidgetVariables(uiWidget)

        # Set scene in MRML widgets. Make sure that in Qt designer the top-level qMRMLWidget's
        # "mrmlSceneChanged(vtkMRMLScene*)" signal in is connected to each MRML widget's.
        # "setMRMLScene(vtkMRMLScene*)" slot.
        uiWidget.setMRMLScene(slicer.mrmlScene)

        # Create logic class. Logic implements all computations that should be possible to run
        # in batch mode, without a graphical user interface.
        self.segmentLS = DeepLSLogic()
        self.gradeLS=LSGradeLogic()
        self.processBatchLS=LSProcessBatch()

        # Connections

        # These connections ensure that we update parameter node when scene is closed
        self.addObserver(slicer.mrmlScene, slicer.mrmlScene.StartCloseEvent, self.onSceneStartClose)
        self.addObserver(slicer.mrmlScene, slicer.mrmlScene.EndCloseEvent, self.onSceneEndClose)

        # Buttons
        self.ui.segmentButton.connect("clicked(bool)", self.onSegmentButton)
        self.ui.gradeButton.connect("clicked(bool)", self.onGradeButton)
        self.ui.processBatchButton.connect("clicked(bool)", self.onProcessBatchButton)
        self.ui.resetButton.connect("clicked(bool)", self.onResetButton)

        #Set Home Directory for batch processing export
        from pathlib import Path
        home = str(Path.home())
        self.ui.DirectoryButton.directory=home

        # Make sure parameter node is initialized (needed for module reload)
        self.initializeParameterNode()

        #Downloading the Models
        try:
            # Aug 5 Start
            if platform.system() == "Darwin":
                model_path="/Applications/slicer.app/Contents/lsmodels/"
            else:
                model_path=os.getcwd()+"/lsmodels/"    

            os.makedirs(model_path,exist_ok=True)
            files=os.listdir(model_path)
        
            #Check if the models are already downloaded. If so, do not download
            if len(files)==6:
                slicer.util.mainWindow().statusBar().showMessage("Models are up-to-date!")
            else:
                #Download Models
                progressbar = slicer.util.createProgressDialog(parent=slicer.util.mainWindow(), value=0, maximum=100,windowTitle="Downloading Lumbar Spine Models....",autoClose=True)
                progressbar.setMinimumWidth(390)

                import requests
                files=['SpineSeg_Fold0_Epoch35_Dice0.9847_IoU0.9710.pth'
                       ,'SpineSeg_Fold1_Epoch45_Dice0.9892_IoU0.9788.pth'
                       ,'SpineSeg_Fold2_Epoch37_Dice0.9881_IoU0.9766.pth'
                       ,'SpineSeg_Fold3_Epoch43_Dice0.9889_IoU0.9782.pth'
                       ,'SpineSeg_Fold4_Epoch27_Dice0.9891_IoU0.9784.pth'
                       ,'SpineCls_Epoch146_Bal_Acc81.3199.pth']

                count=0
                fcount=len(files)
                for fname in files:
                    count+=1
                    if progressbar.wasCanceled:
                        progressbar.close()
                        slicer.util.mainWindow().statusBar().showMessage("Canceled by user")
                        break

                    if "SpineSeg" in fname:
                        git_url='https://github.com/Oulu-IMEDS/lsmodels/raw/main/segmentation/'
                    else:
                        git_url='https://github.com/Oulu-IMEDS/lsmodels/raw/main/grading/' 

                    file_url = git_url+fname
                    if platform.system() == "Darwin":
                        model_path="/Applications/slicer.app/Contents/lsmodels/"+fname
                    else:
                        model_path=os.getcwd()+"/lsmodels/"+fname    
                    # model_path=os.getcwd()+"/lsmodels/"+fname
                    response = requests.get(file_url)

                    if response.status_code == 200:
                    # Write the content to a file
                        with open(model_path, 'wb') as file:
                            file.write(response.content)
                        slicer.util.mainWindow().statusBar().showMessage(f"Models Downloaded")    
                    else:
                        slicer.util.mainWindow().statusBar().showMessage(f"Failed to download models: {response.status_code}")

                    #Set Progress Bar Info
                    progressbar.labelText = f'Downloading {count}/{fcount} models'
                    perc=round((count)*100/fcount,0)
                    slicer.app.processEvents()
                    progressbar.setValue(perc)                            

        except Exception as e:
            slicer.util.mainWindow().statusBar().showMessage(f"Failed to download the Lumbar Spine models")        
            print(e)
                
        #Aug 5 End   
    def cleanup(self) -> None:
        """Called when the application closes and the module widget is destroyed."""
        self.removeObservers()

    def enter(self) -> None:
        """Called each time the user opens this module."""
        # Make sure parameter node exists and observed
        self.initializeParameterNode()

    def exit(self) -> None:
        """Called each time the user opens a different module."""
        # Do not react to parameter node changes (GUI will be updated when the user enters into the module)
        if self._parameterNode:
            self._parameterNode.disconnectGui(self._parameterNodeGuiTag)
            self._parameterNodeGuiTag = None
            self.removeObserver(self._parameterNode, vtk.vtkCommand.ModifiedEvent, self._checkCanApply)

    def onSceneStartClose(self, caller, event) -> None:
        """Called just before the scene is closed."""
        # Parameter node will be reset, do not use it anymore
        self.setParameterNode(None)

    def onSceneEndClose(self, caller, event) -> None:
        """Called just after the scene is closed."""
        # If this module is shown while the scene is closed then recreate a new parameter node immediately
        if self.parent.isEntered:
            self.initializeParameterNode()

    def initializeParameterNode(self) -> None:
        """Ensure parameter node exists and observed."""
        # Parameter node stores all user choices in parameter values, node selections, etc.
        # so that when the scene is saved and reloaded, these settings are restored.

        self.setParameterNode(self.segmentLS.getParameterNode())
        self.setParameterNode(self.gradeLS.getParameterNode())
        self.setParameterNode(self.processBatchLS.getParameterNode())

        # Select default input nodes if nothing is selected yet to save a few clicks for the user
        if not self._parameterNode.inputVolume:
            firstVolumeNode = slicer.mrmlScene.GetFirstNodeByClass("vtkMRMLScalarVolumeNode")
            if firstVolumeNode:
                self._parameterNode.inputVolume = firstVolumeNode

    def setParameterNode(self, inputParameterNode: Optional[DeepLSParameterNode]) -> None:
        """
        Set and observe parameter node.
        Observation is needed because when the parameter node is changed then the GUI must be updated immediately.
        """

        if self._parameterNode:
            self._parameterNode.disconnectGui(self._parameterNodeGuiTag)
            self.removeObserver(self._parameterNode, vtk.vtkCommand.ModifiedEvent, self._checkCanApply)
        self._parameterNode = inputParameterNode
        if self._parameterNode:
            # Note: in the .ui file, a Qt dynamic property called "SlicerParameterName" is set on each
            # ui element that needs connection.
            self._parameterNodeGuiTag = self._parameterNode.connectGui(self.ui)
            self.addObserver(self._parameterNode, vtk.vtkCommand.ModifiedEvent, self._checkCanApply)
            self._checkCanApply()

    def _checkCanApply(self, caller=None, event=None) -> None:
        if self._parameterNode and self._parameterNode.inputVolume:            
            self.ui.segmentButton.toolTip = _("Segment Lumbar Spine")
            self.ui.gradeButton.toolTip = _("Grade Lumbar Spine")
            self.ui.segmentButton.enabled = True
            self.ui.gradeButton.enabled = True
            self.ui.processBatchButton.enabled = True
        else:
            self.ui.segmentButton.toolTip = _("Select input and output volume nodes")
            self.ui.gradeButton.toolTip = _("Select input and output volume nodes")
            self.ui.segmentButton.enabled = False
            self.ui.gradeButton.enabled = False
            self.ui.processBatchButton.enabled = True

    def onSegmentButton(self) -> None:
        """Run processing when user clicks "Segment" button."""
        with slicer.util.tryWithErrorDisplay(_("Failed to segment lumbar spine."), waitCursor=True):
            # Auto Segment the current slice
            self.segmentLS.process(self.ui.inputSelector.currentNode())
    
    def onGradeButton(self) -> None:
        """Run processing when user clicks "Grade" button."""
        with slicer.util.tryWithErrorDisplay(_("Failed to grade lumbar spine."), waitCursor=True):
            # Grade and calcuate the Disc Height Index
            self.gradeLS.process(self.ui.inputSelector.currentNode())

    def onProcessBatchButton(self) -> None:
        """Run processing when user clicks "Process Batch" button."""
        with slicer.util.tryWithErrorDisplay(_("Failed to process batch"), waitCursor=True):
            # Batch Processing of DICOMs
            output_directory=self.ui.DirectoryButton.directory
            self.processBatchLS.process(self.ui.inputSelector.currentNode())
    
    def onResetButton(self) -> None:
        """Run processing when user clicks "Reset" button."""
        with slicer.util.tryWithErrorDisplay(_("Failed to reset."), waitCursor=True):
            slicer.util.mainWindow().statusBar().showMessage("Resetting the scene..")
            slicer.mrmlScene.Clear()
            self.setCustomLayout()

#
# DeepLSLogic
#

from segmentation_models_pytorch import FPN
import torch
from torchvision.models import efficientnet_b0, EfficientNet_B0_Weights
import torch.nn as nn
import albumentations as A
from albumentations.pytorch import ToTensorV2
import numpy as np
from pathlib import Path,PurePath
import matplotlib.pyplot as plt
import cv2
# Imports for disc height
import itertools
import math

# Segmentation Model
class SpineSeg(nn.Module):
    def __init__(self):
        super(SpineSeg, self).__init__()
        self.model=FPN(encoder_name='resnet34',encoder_weights='imagenet',in_channels=1,classes=14)
    def forward(self,x):
        return self.model(x)
    
# Disc Height Index Calcuations
class discHeightIndex():
    def __init__(self,fsu):
        self.fsu=fsu

    def get_vb_corners(self,masks):
        import shapely

        vb_masks = masks[0], masks[2]
        corners = []
        for vb_mask in vb_masks:
            vb_mask = cv2.GaussianBlur(vb_mask, (3,3), 0)
            corners_coords = cv2.goodFeaturesToTrack(vb_mask, 20, 0.01, 10)
            corners_coords = np.int0(corners_coords)

            areas = []
            coordinates = []
            for p in itertools.combinations(np.array(corners_coords),4):
                for r in itertools.permutations(p,4):

                    array = np.concatenate(r)

                    pgon = shapely.Polygon(array)
                    area = pgon.area

                    coordinates.append(r)
                    areas.append(area)

            best_corners = coordinates[areas.index(max(areas))]
            corners.append(best_corners)
            
        return corners

    def get_polygons(self,masks):
        polygons = []
        for mask in masks:
            # mask, header = nrrd.read(mask)
            contours = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            contours = contours[0] if len(contours) == 2 else contours[1]
            c = max(contours, key=cv2.contourArea)
            polygons.append(c)

        return masks, polygons


    def get_ivd_midline_cv2_fitline(self,masks, polygons):
        import shapely

        [vx, vy, x, y] = cv2.fitLine(polygons[1], cv2.DIST_L2, 0, 0.01, 0.01)

        ivd_mask = masks[1]

        rows,cols = ivd_mask.shape[:2]
        lefty = int((-x * vy / vx) + y)
        righty = int(((cols - x) * vy / vx) + y)
        line = [(cols,righty), (0,lefty)]

        ivd_cv2_fit_midline = shapely.geometry.LineString(line)

        return ivd_cv2_fit_midline


    def midpoint(self,x0, y0, x1, y1):
        import shapely
        return shapely.Point((x0 + x1)/2, (y0 + y1)/2)


    def extend_line(self,line, factor):
        """
        Extend a line by a factor of 2
        """
        import shapely
        x0, y0, x1, y1 = line.bounds
        mid = self.midpoint(x0, y0, x1, y1)
        extended_line = shapely.affinity.scale(line, xfact=factor, yfact=factor, origin=mid)
        return extended_line


    def get_point_on_vector(self,initial_pt, terminal_pt, distance):

        v = np.array(initial_pt, dtype=float)
        u = np.array(terminal_pt, dtype=float)
        n = v - u
        n /= np.linalg.norm(n, 2)
        point = v - distance * n

        return tuple(point)    


    def cut_polygon_by_line(self,polygon, line):
        from shapely.ops import linemerge, unary_union, polygonize
        merged = linemerge([polygon.boundary, line])
        borders = unary_union(merged)
        polygons = polygonize(borders)

        return list(polygons)


    def label_vb_corners(self,ivd_cv2_fit_midline, polygons, corners):
        import shapely
        contour = np.squeeze(polygons[1])
        shapely_poly = shapely.geometry.Polygon(contour)

        # Find the intersection points between the fit midline and the IVD contour:
        intersection = shapely_poly.intersection(ivd_cv2_fit_midline)
        if intersection.geom_type == "LineString":
            x0 = intersection.coords[0][0]
            y0 = intersection.coords[0][1]
            x1 = intersection.coords[1][0]
            y1 = intersection.coords[1][1]
        elif intersection.geom_type == "MultiLineString":
            # sometimes the midline will cross the IVD polygon multiple times because it has curves
            coords = np.asarray([l.coords for l in intersection.geoms])
            x0 = coords[:,0][0][0]
            y0 = coords[:,0][0][1]
            x1 = coords[:,-1][-1][0]
            y1 = coords[:,-1][-1][1] #taking only the first and the last coordinates of the intersection line and ignoring any intermediate ones that might get picked up
        elif intersection.geom_type == "GeometryCollection":
            # sometimes there is a single point appended at the end and we need to skip it
            list_coords = []
            for geom in intersection.geoms:
                coords = np.asarray([geom.coords])
                list_coords.append(coords)
            x0 = list_coords[0][:,0][0][0]
            y0 = list_coords[0][:,0][0][1]
            x1 = list_coords[-2][:,-1][-1][0]
            y1 = list_coords[-2][:,-1][-1][1]
            intersection = shapely.geometry.LineString([(x0, y0), (x1, y1)])
        
        # Find points in corners that are closest to the intersection points
        # Get the distance between the intersection points and the corners
        # x0, y0 are the anterior IVD midline intersection coordinates, x1, y1 are the posterior IVD midline intersection coordinates
        corners = np.vstack(corners)

        anterior = [] # Not necessarily anterior or posterior, but at least separated 
        anterior_ivd = (x0, y0)
        for c in corners:
            corner = c[0]
            distance = math.dist(anterior_ivd, corner)
            anterior.append(distance)

        posterior = []
        posterior_ivd = (x1, y1)
        for c in corners:
            corner = c[0]
            distance = math.dist(posterior_ivd, corner)
            posterior.append(distance)

        # Find the index of the minimum two distances using np.argpartition()
        smallest_anterior_idx = np.argpartition(anterior, 2)
        smallest_posterior_idx = np.argpartition(posterior, 2)

        # Get the two points that are closest to the intersection points
        two_anterior_corners = corners[smallest_anterior_idx[:2]]
        two_posterior_corners = corners[smallest_posterior_idx[:2]]

        return two_anterior_corners, two_posterior_corners


    def get_ivd_midline_vb_corners(self,ivd_cv2_fit_midline, polygons, corners):
        import shapely

        two_anterior_corners, two_posterior_corners = self.label_vb_corners(ivd_cv2_fit_midline, polygons, corners)

        anterior_midpoint = self.midpoint(two_anterior_corners[0][0][0],
                                    two_anterior_corners[0][0][1],
                                    two_anterior_corners[1][0][0],
                                    two_anterior_corners[1][0][1])
        posterior_midpoint = self.midpoint(two_posterior_corners[0][0][0],
                                    two_posterior_corners[0][0][1],
                                    two_posterior_corners[1][0][0],
                                    two_posterior_corners[1][0][1])
        
        # Create a line between the two midpoints
        ivd_midline = shapely.geometry.LineString([anterior_midpoint, posterior_midpoint])

        extended_ivd_midline = self.extend_line(ivd_midline, 2)

        # Convert the cv2 contour to a shapely polygon
        contour = np.squeeze(polygons[1])
        shapely_poly = shapely.geometry.Polygon(contour)

        # Find the intersection points
        intersections = shapely_poly.intersection(extended_ivd_midline)

        if intersections.geom_type == "MultiLineString":
            # sometimes the midline will cross the IVD polygon multiple times because it has curves
            coords = np.asarray([l.coords for l in intersections.geoms])
            x0 = coords[:,0][0][0]
            y0 = coords[:,0][0][1]
            x1 = coords[:,-1][-1][0]
            y1 = coords[:,-1][-1][1]
            intersections = shapely.geometry.LineString([(x0, y0), (x1, y1)])
        
        if intersections.geom_type == "GeometryCollection":
            # sometimes there is a single point appended at the end and we need to skip it
            list_coords = []
            for geom in intersections.geoms:
                coords = np.asarray([geom.coords])
                list_coords.append(coords)
            x0 = list_coords[0][:,0][0][0]
            y0 = list_coords[0][:,0][0][1]
            x1 = list_coords[-2][:,-1][-1][0]
            y1 = list_coords[-2][:,-1][-1][1]
            intersections = shapely.geometry.LineString([(x0, y0), (x1, y1)])

        disc_diameter = math.sqrt((intersections.coords[1][0] - intersections.coords[0][0])**2 + (intersections.coords[1][1] - intersections.coords[0][1])**2)

        # return extended_ivd_midline, intersections, anterior_midpoint, posterior_midpoint, disc_diameter
        return intersections, disc_diameter

    def get_vb_diameter(self,corners, ivd_cv2_fit_midline, polygon):
        import shapely 
        # get perpendicular distances from vb corners to ivd midline
        # This is needed to identify the upper and lower corners
        # these for loops will give the perpendicular distance from each corner to the IVD midline
        corner_distances = []
        for corner in corners:
            corner_distances.append(ivd_cv2_fit_midline.distance(shapely.Point(corner[0])))

        # Find the index of the largest two distances using np.argpartition()
        # The largest two distances are the two corners that are farthest from the IVD midline, and therefore the upper and lower corners of the adjacent vertebrae
        lower_corner_idx = np.argpartition(corner_distances, -2) # top two distances i.e. last two entries on the index list
        upper_corner_idx = np.argpartition(corner_distances, 2) # bottom two distances i.e. first two entries on the index list

        # Get the two points that are closest to the intersection points
        stacked_corners = np.vstack(corners)
        lower_corners = stacked_corners[lower_corner_idx[:2]] # index from the corners based on the results of the previous block of code
        upper_corners = stacked_corners[upper_corner_idx[-2:]]

        # get the midpoints of every possible two lines connecting the upper and lower corners
        m1 = self.midpoint(lower_corners[0][0], lower_corners[0][1], upper_corners[0][0], upper_corners[0][1])
        m2 = self.midpoint(lower_corners[0][0], lower_corners[0][1], upper_corners[1][0], upper_corners[1][1])
        m3 = self.midpoint(lower_corners[1][0], lower_corners[1][1], upper_corners[0][0], upper_corners[0][1])
        m4 = self.midpoint(lower_corners[1][0], lower_corners[1][1], upper_corners[1][0], upper_corners[1][1])

        # get the distance between midpoints of every possible two lines connecting the upper and lower corners
        d1 = m1.distance(m2)
        d2 = m3.distance(m4)
        d3 = m1.distance(m3)
        d4 = m2.distance(m4)
        d5 = m1.distance(m4)
        d6 = m2.distance(m3)
        midpoints = [[m1, m2], [m3, m4], [m1, m3], [m2, m4], [m1, m4], [m2, m3]]
        d = [d1, d2, d3, d4, d5, d6]

        # The two that are further apart represent the two lines conencting the upper and lower corners of the vertebra
        # find the index of the largest value for distance
        vb_height_mid_points = midpoints[np.argmax(d)]

        # these midpoints then need to get extended to make sure they will intersect with the VB polygon,
        # and then those intersections can be used to calculate the VB diameter
        vb_midline = shapely.geometry.LineString([vb_height_mid_points[0], vb_height_mid_points[1]])

        # VB midline inclinication:
        x0 = vb_midline.coords[0][0]
        y0 = vb_midline.coords[0][1]
        x1 = vb_midline.coords[1][0]
        y1 = vb_midline.coords[1][1]

        # Find the angle of the line
        theta = math.atan2((y1 - y0), (x1 - x0))
        slope = (y1 - y0)/(x1 - x0)
        theta = math.atan(slope)
        vb_midline_inclination = math.degrees(theta)

        # use the extend line function from above
        extended_vb_midline = self.extend_line(vb_midline, 2)

        vb_contour = np.squeeze(polygon)
        vb_shapely_poly = shapely.geometry.Polygon(vb_contour)

        # Find the intersection points
        vb_diameter_points = vb_shapely_poly.intersection(extended_vb_midline)

        if vb_diameter_points.geom_type == "MultiLineString":
            # sometimes the midline will cross the VB polygon multiple times because it has curves
            coords = np.asarray([l.coords for l in vb_diameter_points.geoms])
            x0 = coords[:,0][0][0]
            y0 = coords[:,0][0][1]
            x1 = coords[:,-1][-1][0]
            y1 = coords[:,-1][-1][1]
            vb_diameter_points = shapely.geometry.LineString([(x0, y0), (x1, y1)])

        vb_diameter = vb_diameter_points.length

        # return vb_diameter, vb_diameter_points, lower_corners, upper_corners, vb_midline_inclination
        return vb_diameter, vb_midline_inclination

    def cut_polygon_by_lines(self,intersections, polygons, mu):
        """
        Based on percentage value mu, cut the polygon into two parts
        """
        import shapely 

        x0 = intersections.coords[0][0]
        y0 = intersections.coords[0][1]
        x1 = intersections.coords[1][0]
        y1 = intersections.coords[1][1]

        # Find the angle of the line
        theta = math.atan2((y1 - y0), (x1 - x0))
        slope = (y1 - y0)/(x1 - x0)
        theta = math.atan(slope)
        ivd_inclination = math.degrees(theta)

        # Find the points that contain the central mu% of the line
        # Find the distance between the points
        IVD_length = math.sqrt((x1 - x0)**2 + (y1 - y0)**2)
        distance = (IVD_length - (IVD_length * mu)) / 2
        start_point = (x0, y0)
        end_point = (x1, y1)

        point_a = self.get_point_on_vector(start_point, end_point, distance)
        point_b = self.get_point_on_vector(end_point, start_point, distance)
        point_c = self.midpoint(x0, y0, x1, y1) # for getting the central point of the IVD

        # Find the perpendicular lines
        if slope == 0:
            angle =  math.pi / 2
        else:
            perp_slope = -1.0 / slope
            angle = math.atan(perp_slope)

        length = 30
        start = shapely.geometry.Point(point_a[0] - length * math.cos(angle),
                                    point_a[1] - length * math.sin(angle))
        end = shapely.geometry.Point(point_a[0] + length * math.cos(angle),
                                    point_a[1] + length * math.sin(angle))
        line_a = shapely.geometry.LineString([start, end])

        start = shapely.geometry.Point(point_b[0] - length * math.cos(angle),
                                    point_b[1] - length * math.sin(angle))
        end = shapely.geometry.Point(point_b[0] + length * math.cos(angle),
                                    point_b[1] + length * math.sin(angle))
        line_b = shapely.geometry.LineString([start, end])

        start = shapely.geometry.Point(point_c.x - length * math.cos(angle),
                                    point_c.y - length * math.sin(angle))
        end = shapely.geometry.Point(point_c.x + length * math.cos(angle),
                                    point_c.y + length * math.sin(angle))
        line_c = shapely.geometry.LineString([start, end])

        # Convert the cv2 contour to a shapely polygon
        contour = np.squeeze(polygons[1])
        shapely_poly = shapely.geometry.Polygon(contour)

        # intersections_a = shapely_poly.intersection(line_a)
        # intersections_b = shapely_poly.intersection(line_b)
        short_midline_intersections = shapely_poly.intersection(line_c)
        if short_midline_intersections.geom_type == "MultiLineString":
            # sometimes the midline will cross the VB polygon multiple times because it has curves
            coords = np.asarray([l.coords for l in short_midline_intersections.geoms])
            x0 = coords[:,0][0][0]
            y0 = coords[:,0][0][1]
            x1 = coords[:,-1][-1][0]
            y1 = coords[:,-1][-1][1]
            short_midline_intersections = shapely.geometry.LineString([(x0, y0), (x1, y1)])

        cut_1 = self.cut_polygon_by_line(shapely_poly, line_a)

        # sometimes with an unusually shaped disc the lines splitting the disc will result in 3 or 4 polygons, not two. In this case, return the two polygons with the largest area
        if len(cut_1) > 2:
            areas = [p.area for p in cut_1]
            largest_area = max(areas)
            largest_area_index = areas.index(largest_area)
            polygons_a = [cut_1[largest_area_index]]

            # remove the largest area from the list
            areas.pop(largest_area_index)
            largest_area = max(areas)
            largest_area_index = areas.index(largest_area)
            polygons_a.append(cut_1[largest_area_index])
        
        else:   
            polygons_a = cut_1

        cut_2 = self.cut_polygon_by_line(shapely_poly, line_b)

        # if polygon_b length is greater than 2, return the two polygons with the largest area
        if len(cut_2) > 2:
            areas = [p.area for p in cut_2]
            largest_area = max(areas)
            largest_area_index = areas.index(largest_area)
            polygons_b = [cut_2[largest_area_index]]

            # remove the largest area from the list
            areas.pop(largest_area_index)
            largest_area = max(areas)
            largest_area_index = areas.index(largest_area)
            polygons_b.append(cut_2[largest_area_index])
        
        else:
            polygons_b = cut_2

        polygons = polygons_a + polygons_b

        return polygons, ivd_inclination


    def get_mid_polygon(self,polygons):
        """
        Return the polygon that covers the centre of the IVD
        """
        indexes = [0, 1, 2, 3]
        pairs = [(a, b) for idx, a in enumerate(indexes) for b in indexes[idx + 1:]]

        intersections = []
        for pair in pairs:
            intersection = polygons[pair[0]].intersection(polygons[pair[1]])
            intersections.append(intersection)
        ivd_centre = max(intersections, key=lambda x: x.area)
        # get area of disc centre

        return ivd_centre


    def get_areas(self,polygons, ivd_centre):
        import shapely

        central_ivd_area = ivd_centre.area

        contour = np.squeeze(polygons[1])
        ivd_poly = shapely.geometry.Polygon(contour)
        total_ivd_area = ivd_poly.area

        contour = np.squeeze(polygons[0])
        upper_vb_poly = shapely.geometry.Polygon(contour)
        upper_vb_area = upper_vb_poly.area

        contour = np.squeeze(polygons[2])
        lower_vb_poly = shapely.geometry.Polygon(contour)
        lower_vb_area = lower_vb_poly.area

        return central_ivd_area, total_ivd_area, upper_vb_area, lower_vb_area


    def calculate_indices(self):

    #     cranial_vb_mask, _ = nrrd.read(fsu[0])
    #     ivd_mask, _ = nrrd.read(fsu[1])
    #     caudal_vb_mask, _ = nrrd.read(fsu[2])
    #     fsu = [cranial_vb_mask, ivd_mask, caudal_vb_mask]
        fsu, polygons = self.get_polygons(self.fsu)

        # IVD midline based on CV2 fit
        ivd_cv2_fit_midline = self.get_ivd_midline_cv2_fitline(fsu, polygons)
        
        corners = self.get_vb_corners(fsu)

        cranial_vb_diameter,cranial_vb_midline_inclination = self.get_vb_diameter(corners[0], ivd_cv2_fit_midline, polygons[0])

        caudal_vb_diameter, caudal_vb_midline_inclination = self.get_vb_diameter(corners[1], ivd_cv2_fit_midline, polygons[2])

        # IVD midline based on VB corners 
        intersections, disc_diameter = self.get_ivd_midline_vb_corners(ivd_cv2_fit_midline, polygons, corners)

        # Cutting the IVD into 3 parts based on mu percentage
        ivd_segmentation_polygons, ivd_inclination = self.cut_polygon_by_lines(intersections, polygons = polygons, mu = 0.8)

        # Get the middle part of the IVD
        ivd_centre = self.get_mid_polygon(ivd_segmentation_polygons)

        # Calculate the areas
        central_ivd_area, ivd_area, cranial_vb_area, caudal_vb_area = self.get_areas(polygons, ivd_centre)

        cranial_vb_height = cranial_vb_area / cranial_vb_diameter
        caudal_vb_height = caudal_vb_area / caudal_vb_diameter
        ivd_height = central_ivd_area / disc_diameter

        # Final calculation of indices
        ivd_height_index = 2 * ivd_height / (cranial_vb_height + caudal_vb_height)

        
        return f"{ivd_height_index:.3f}"

# Perform Spine Segmentation               
class autoSegment():

    def __init__(self,input_slice):
        self.current_slice=input_slice
        self.device= "cuda" if torch.cuda.is_available() else "cpu"

    def predict(self):    
        # Load Segmentation Model
        if platform.system() == "Darwin":
            model_path="/Applications/slicer.app/Contents/lsmodels/"
        else:
            model_path=os.getcwd()+"/lsmodels/"    
        #model_path=os.getcwd()+"/lsmodels/"
        checkpoints = list(Path(model_path).glob("SpineSeg*"))

        models=[]
        for checkpoint in checkpoints:
            model_checkpoint = checkpoint
            model= SpineSeg()
            state = torch.load(model_checkpoint,map_location=self.device,weights_only=False)['model_state']
            model.load_state_dict(state)
            model.eval()
            model.to(self.device)
            models.append(model)
        
        #Convert Image to Tensor
        input_img=self.current_slice
        # Convert image to tensor
        transform=A.Compose(
                        [A.Normalize(mean=0.181, std=0.184, always_apply=True, p=1.0),
                         A.Resize(512, 512),
                         ToTensorV2()])
        image_tensor=transform(image=input_img)['image']
        image_tensor=image_tensor.unsqueeze(0).float()

        # Make Prediction
        prediction=0
        for model in models:
            prediction += model(image_tensor.to(self.device))
        pred=prediction/len(checkpoints)    
        pred = pred.squeeze().to('cpu').argmax(0).numpy()
        return pred

# Utilities
class deepUtils():
    def __init__(self) -> None:
        pass
        
    def int16_to_uint8(self,int16_image):

        # Find the minimum and maximum values in the image
        min_val = np.min(int16_image)
        max_val = np.max(int16_image)

        # Rescale the image to the 0-255 range of uint8
        if min_val != max_val:
            scale = 255.0 / (max_val - min_val)
            uint8_image = ((int16_image - min_val) * scale).round().astype(np.uint8)
        else:
            # Handle the case where all pixels have the same value
            uint8_image = np.ones_like(int16_image, dtype=np.uint8) * min_val

        return uint8_image


    def set_segments(self,segmentationNode,volumeNode,pred_array,slice_index,series_count):
        segments=segmentationNode.GetSegmentation()
        spine_segments={1:'S1',2:'D5',3:'L5',4:'D4',5:'L4',6:'D3',7:'L3',8:'D2',9:'L2',10:'D1',11:'L1'}
        width=pred_array.shape[0]
        height=pred_array.shape[1]
        #Set voxel prediction
        for i in range(1,12):
            seg_array=np.where(pred_array!=i,0,pred_array)
            voxel_arr_seg=np.zeros((series_count,width,height),dtype=np.uint8)
            voxel_arr_seg[slice_index]=seg_array
            slicer.util.updateSegmentBinaryLabelmapFromArray(voxel_arr_seg, segmentationNode, segments.GetSegmentIdBySegmentName(spine_segments[i]),volumeNode)    
        
        
    def clearsegmentation(self,nodename):
        allSegmentNodes = slicer.util.getNodes('vtkMRMLSegmentationNode*').values()
        for ctn in allSegmentNodes:
            teststr = ctn.GetName()
            if nodename in teststr:
                slicer.mrmlScene.RemoveNode(ctn)
        
        
    def update_segmentation_slicer(self,volumeNode,pred_array,slice_index,series_count):

        #creating new segmentation node and segment and set its reference image geometry to volume node
        self.clearsegmentation(f"Slice#{slice_index}")
        segmentationNode = slicer.vtkMRMLSegmentationNode()
        segmentationNode.SetName(f"Slice#{slice_index}")
        slicer.mrmlScene.AddNode(segmentationNode)
        segmentationNode.CreateDefaultDisplayNodes()
        segmentationNode.SetReferenceImageGeometryParameterFromVolumeNode(volumeNode)
        segments=segmentationNode.GetSegmentation()

        #Add the required Segments
        classes={1:'L1',2:'D1',3:'L2',4:'D2',5:'L3',6:'D3',7:'L4',8:'D4',9:'L5',10:'D5',11:'S1'}
        for i in range(1,12):
            segments.AddEmptySegment(classes[i])

        self.set_segments(segmentationNode,volumeNode,pred_array,slice_index,series_count)

# Autograding 
class autoGrade:
    def __init__(self,input_img,segmentation,custom_layout='Y'):
        self.input_mri=input_img
        self.prediction=segmentation   
        self.layout=custom_layout
        self.device="cuda" if torch.cuda.is_available() else "cpu"
    def get_spine_unit_rect(self,input_image, model_prediction, spine_unit):
        if (input_image.shape[0], input_image.shape[1]) != (512, 512):
            resized_input = cv2.resize(input_image, (512, 512), interpolation=cv2.INTER_CUBIC)
        else:
            resized_input = input_image
        if spine_unit == 'l1-l2':
            s_unit = (np.uint8(model_prediction == 11) + np.uint8(
                model_prediction == 10) + np.uint8(
                model_prediction == 9)) * 255
        elif spine_unit == 'l2-l3':
            s_unit = (np.uint8(model_prediction == 9) + np.uint8(
                model_prediction == 8) + np.uint8(
                model_prediction == 7)) * 255
        elif spine_unit == 'l3-l4':
            s_unit = (np.uint8(model_prediction == 7) + np.uint8(
                model_prediction == 6) + np.uint8(
                model_prediction == 5)) * 255
        elif spine_unit == 'l4-l5':
            s_unit = (np.uint8(model_prediction == 5) + np.uint8(
                model_prediction == 4) + np.uint8(
                model_prediction == 3)) * 255
        elif spine_unit == 'l5-s1':
            s_unit = (np.uint8(model_prediction == 3) + np.uint8(
                model_prediction == 2) + np.uint8(
                model_prediction == 1)) * 255

        contours, hierarchy = cv2.findContours(s_unit, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        # Find the area of contours to determine if the slice is worth looking into for
        if contours:
            big_contour = max(contours, key=cv2.contourArea)
            contour_area = cv2.contourArea(big_contour)
            # logger.info(f"Contour Area:{contour_area} Unit:{spine_unit}")
            # If the code is not able to detect contours it could be a bad slice to use
            if spine_unit in ('l1-l2', 'l2-l3', 'l3-l4', 'l4-l5', 'l5-s1') and contour_area < 10:
                return 0
            else:
                x, y, width, height = cv2.boundingRect(big_contour)
                result = resized_input[y:y + height, x:x + width]
                # If resultant crop has dimensions more than intended crop dimensions, apply resize
                if (result.shape[0], result.shape[1]) != (224, 224):
                    if result.shape[0] < 224 or result.shape[1] < 224:
                        result = cv2.resize(result,
                                            (224, 224),
                                            interpolation=cv2.INTER_AREA)
                    else:
                        result = cv2.resize(result,
                                            (224, 224),
                                            interpolation=cv2.INTER_AREA)
            return result 

    def transform_and_stack(self,input_image):
        test_transform = A.Compose(
            [A.Resize(224, 224),
            A.Normalize(mean=0.235, std=0.134, always_apply=True, p=1.0),
            ToTensorV2()])

        transformed = test_transform(image=input_image)
        transformed_img = transformed['image']
        transformed_img = transformed_img.type(torch.FloatTensor)

        transformed_images = []
        for i in range(4):
            transformed_images.append(transformed_img)

        transformed_images = torch.Tensor(np.stack(transformed_images))
        return transformed_images
    
    def make_spine_grading(self,input_mri, segmentation):

        if platform.system() == "Darwin":
            model_path="/Applications/slicer.app/Contents/lsmodels/"
        else:
            model_path=os.getcwd()+"/lsmodels/"    

        # model_path=os.getcwd()+"/lsmodels/"
        checkpoint = list(Path(model_path).glob("SpineCls*"))[0]
        classification_model = efficientnet_b0(weights=EfficientNet_B0_Weights.DEFAULT)
        classification_model.features[0][0] = nn.Conv2d(4, 32, kernel_size=(3, 3), stride=(2, 2),
                                                        padding=(1, 1), bias=False)

        classification_model.classifier = nn.Sequential(nn.Linear(1280, 512),
                                                        nn.Dropout(p=0.2),
                                                        nn.Linear(512, 256),
                                                        nn.Linear(256, 4))
        state = torch.load(checkpoint,map_location=torch.device(self.device),weights_only=False)['model_state']
        classification_model.load_state_dict(state)
        classification_model = classification_model.to(self.device)
        classification_model.eval()

        # Get the individual patches for the discs
        l1_l2_patch = self.get_spine_unit_rect(input_mri, segmentation, 'l1-l2')
        l1_l2_stack = self.transform_and_stack(l1_l2_patch)
        l2_l3_patch = self.get_spine_unit_rect(input_mri, segmentation, 'l2-l3')
        l2_l3_stack = self.transform_and_stack(l2_l3_patch)
        l3_l4_patch = self.get_spine_unit_rect(input_mri, segmentation, 'l3-l4')
        l3_l4_stack = self.transform_and_stack(l3_l4_patch)
        l4_l5_patch = self.get_spine_unit_rect(input_mri, segmentation, 'l4-l5')
        l4_l5_stack = self.transform_and_stack(l4_l5_patch)
        l5_s1_patch = self.get_spine_unit_rect(input_mri, segmentation, 'l5-s1')
        l5_s1_stack = self.transform_and_stack(l5_s1_patch)

        model_input = torch.Tensor(np.stack([l1_l2_stack, l2_l3_stack, l3_l4_stack, l4_l5_stack, l5_s1_stack]))

        predictions = classification_model(model_input.squeeze(2).to(self.device))
        final_result = predictions.argmax(axis=1).detach().cpu().numpy()

        return final_result
       
    def setSlicerTable(self,pred,grades):
        class_to_grades = {0:'2', 1: '3', 2: '4', 3: '5'}

        l1_2=[np.where(pred==11,200,0).astype('uint8'),np.where(pred==10,200,0).astype('uint8'),np.where(pred==9,200,0).astype('uint8')]
        l2_3=[np.where(pred==9,200,0).astype('uint8'),np.where(pred==8,200,0).astype('uint8'),np.where(pred==7,200,0).astype('uint8')]
        l3_4=[np.where(pred==7,200,0).astype('uint8'),np.where(pred==6,200,0).astype('uint8'),np.where(pred==5,200,0).astype('uint8')]
        l4_5=[np.where(pred==5,200,0).astype('uint8'),np.where(pred==4,200,0).astype('uint8'),np.where(pred==3,200,0).astype('uint8')]
        l5_s1=[np.where(pred==3,200,0).astype('uint8'),np.where(pred==2,200,0).astype('uint8'),np.where(pred==1,200,0).astype('uint8')]

        disc=discHeightIndex(l1_2)
        index_h1=disc.calculate_indices()
        disc=discHeightIndex(l2_3)
        index_h2=disc.calculate_indices()
        disc=discHeightIndex(l3_4)
        index_h3=disc.calculate_indices()
        disc=discHeightIndex(l4_5)
        index_h4=disc.calculate_indices()
        disc=discHeightIndex(l5_s1)
        index_h5=disc.calculate_indices()

        tableNode = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLTableNode")
        tableNode.SetName("Grading Result")
        tableNode.AddColumn().SetName("Metric")
        tableNode.AddColumn().SetName("L1/2")
        tableNode.AddColumn().SetName("L2/3")
        tableNode.AddColumn().SetName("L3/4")
        tableNode.AddColumn().SetName("L4/5")
        tableNode.AddColumn().SetName("L5/S1")
        tableNode.AddEmptyRow()
        tableNode.AddEmptyRow()
        tableNode.SetCellText(0, 0, "Pfirrmann Grade")
        tableNode.SetCellText(0, 1, class_to_grades[grades[0]])
        tableNode.SetCellText(0, 2, class_to_grades[grades[1]])
        tableNode.SetCellText(0, 3, class_to_grades[grades[2]])
        tableNode.SetCellText(0, 4, class_to_grades[grades[3]])
        tableNode.SetCellText(0, 5, class_to_grades[grades[4]])
        tableNode.SetCellText(1, 0, "Disc Height Index")
        tableNode.SetCellText(1, 1, index_h1)
        tableNode.SetCellText(1, 2, index_h2)
        tableNode.SetCellText(1, 3, index_h3)
        tableNode.SetCellText(1, 4, index_h4)
        tableNode.SetCellText(1, 5, index_h5)


        if self.layout=="Y":
            layoutManager = slicer.app.layoutManager()
            layoutTable = slicer.modules.tables.logic().GetLayoutWithTable(layoutManager.layout)
            layoutManager.setLayout(layoutTable)
            
            tablewidget = layoutManager.tableWidget(0)
            tableview = slicer.mrmlScene.GetFirstNodeByClass('vtkMRMLTableViewNode')
            tableview.SetTableNodeID(tableNode.GetID())
            tablewidget.setMRMLTableViewNode(tableview)     
            self.setCustomTableLayout()
        #Nash Jun 12 2024
        return [class_to_grades[grades[0]],class_to_grades[grades[1]],class_to_grades[grades[2]],class_to_grades[grades[3]],class_to_grades[grades[4]],index_h1,index_h2,index_h3,index_h4,index_h5]

            

    def setCustomTableLayout(self):
        customLayout = """
        <layout type="vertical" split="true">
        <item>
        <view class="vtkMRMLSliceNode" singletontag="Yellow">
            <property name="orientation" action="default">Sagittal</property>
            <property name="viewlabel" action="default">Y</property>
            <property name="viewcolor" action="default">#EDD54C</property>
        </view>
        </item>
        <item>
        <view class="vtkMRMLTableViewNode" singletontag="T">
        <property name="viewlabel" action="default">T</property>
        </view>
        </item>
        </layout>
        """

        # Built-in layout IDs are all below 100, so you can choose any large random number
        # for your custom layout ID.
        customLayoutId=501
        layoutManager = slicer.app.layoutManager()
        layoutManager.layoutLogic().GetLayoutNode().AddLayoutDescription(customLayoutId, customLayout)

        # Switch to the new custom layout
        layoutManager.setLayout(customLayoutId)  

    # Add more rows with different data lists
    def grade(self):
        # Call for classification
        grades = self.make_spine_grading(self.input_mri, self.prediction)
        grade_dhi_result=self.setSlicerTable(self.prediction,grades)
        return grade_dhi_result

# Grading Logic
class LSGradeLogic(ScriptedLoadableModuleLogic):
    def __init__(self) -> None:
        """Called when the logic class is instantiated. Can be used for initializing member variables."""
        ScriptedLoadableModuleLogic.__init__(self)
        #Set the custom layout to focus on the sagittal view
           
    def getParameterNode(self):
        return DeepLSParameterNode(super().getParameterNode())    
    
    def process(self,
                inputVolume: vtkMRMLScalarVolumeNode,
                showResult: bool = True) -> None:

        #Check if the input volume is available to process:
        if not inputVolume:
            raise ValueError("Input volume is invalid")    
        
        script_dir = os.path.dirname(os.path.realpath(__file__))
            
        #Start Auto Segmentation    
        startTime = time.time()

        #Get the current slice number
        layoutManager = slicer.app.layoutManager()
        yellow = layoutManager.sliceWidget("Yellow")
        yellowLogic = yellow.sliceLogic()
        offset=yellowLogic.GetSliceOffset()
        slice_index=yellowLogic.GetSliceIndexFromOffset(offset)-1 

        #Extract the slice
        voxels = slicer.util.arrayFromVolume(inputVolume)  # Get volume as numpy array
        series_count=voxels.shape[0]
        mid_saggital=series_count//2
        du=deepUtils()
        slice = du.int16_to_uint8(voxels[mid_saggital,:,:])
        
        #Perform Segmentation
        # autoseg=autoSegment(slice)
        # prediction=autoseg.predict()

        # Start of June 14
        #Check if the Slicer Array for Segmentation is null, If yes, use prediction if not use Slicer Array 11-Jun-2024       
        num_segments=0
        segmentationNode=slicer.util.getFirstNodeByName(f'Slice#{slice_index}')       

        if segmentationNode==None:
            autoseg=autoSegment(slice)
            prediction=autoseg.predict()  
        else:
            segmentation = segmentationNode.GetSegmentation()
            num_segments = segmentation.GetNumberOfSegments()
            #maskArray= np.zeros((512, 512), dtype=np.int64)
            maskArray= np.zeros(slice.shape, dtype=np.uint8)
            classes={'S1':1,'D5':2,'L5':3,'D4':4,'L4':5,'D3':6,'L3':7,'D2':8,'L2':9,'D1':10,'L1':11}                
            offset=yellowLogic.GetSliceOffset()
            slice_index=yellowLogic.GetSliceIndexFromOffset(offset)-1 

            for segment_idx in range(num_segments):
                segment_id = segmentation.GetNthSegmentID(segment_idx)
                segment_name = segmentation.GetSegment(segment_id).GetName()

                # Get the binary labelmap representation of the segment
                segmentArray = slicer.util.arrayFromSegmentBinaryLabelmap(segmentationNode, segment_id)
                slice = du.int16_to_uint8(voxels[slice_index,:,:])
                segmentArray = segmentArray[slice_index,:,:]
                maskArray[segmentArray > 0] = classes[segment_id]

            prediction=maskArray
            #prediction=cv2.resize(prediction,(512,512))
            prediction=prediction.astype(np.int64)

        # End of June 14

        #Perform Grading
        try:
            pfirrmann=autoGrade(slice,prediction)
            result=pfirrmann.grade()
            stopTime = time.time()
            slicer.util.mainWindow().statusBar().showMessage(f"Processing completed in {stopTime-startTime:.2f} seconds")
        except:
            import qt
            msg_box = qt.QMessageBox()
    
            # Set the icon, title, and message
            msg_box.setIcon(qt.QMessageBox.Critical)
            msg_box.setWindowTitle("Error")
            msg_box.setText(f"Unable to Grade. Possible Cause: Poor Segmentations")
            # Show the message box
            msg_box.exec_()
            #slicer.util.mainWindow().statusBar().showMessage(f"Unable to Grade. Possible Cause: Poor Segmentations")            

# Segmentation Logic 
class DeepLSLogic(ScriptedLoadableModuleLogic):
    """This class should implement all the actual
    computation done by your module.  The interface
    should be such that other python code can import
    this class and make use of the functionality without
    requiring an instance of the Widget.
    Uses ScriptedLoadableModuleLogic base class, available at:
    https://github.com/Slicer/Slicer/blob/main/Base/Python/slicer/ScriptedLoadableModule.py
    """

    def __init__(self) -> None:
        """Called when the logic class is instantiated. Can be used for initializing member variables."""
        ScriptedLoadableModuleLogic.__init__(self)

    def getParameterNode(self):
        return DeepLSParameterNode(super().getParameterNode())

    def process(self,
                inputVolume: vtkMRMLScalarVolumeNode,
                showResult: bool = True) -> None:

        #Check if the input volume is available to process:
        if not inputVolume:
            raise ValueError("Input volume is invalid")    
            
        #Start Auto Segmentation    
        startTime = time.time()

        #Get the current slice number
        layoutManager = slicer.app.layoutManager()
        yellow = layoutManager.sliceWidget("Yellow")
        yellowLogic = yellow.sliceLogic()
        offset=yellowLogic.GetSliceOffset()
        slice_index=yellowLogic.GetSliceIndexFromOffset(offset)-1 

        #Extract the slice
        voxels = slicer.util.arrayFromVolume(inputVolume)  # Get volume as numpy array
        series_count=voxels.shape[0]
        du=deepUtils()
        slice = du.int16_to_uint8(voxels[slice_index,:,:])
        
        #Perform Prediction
        autoseg=autoSegment(slice)
        prediction=autoseg.predict()

        if prediction.shape[0]!=voxels.shape[1] or prediction.shape[1]!=voxels.shape[2]:
            prediction=cv2.resize(prediction,(voxels.shape[1],voxels.shape[2]), interpolation=cv2.INTER_NEAREST)

               
        #Update the Segmentations on Slicer
        du.update_segmentation_slicer(inputVolume,prediction,slice_index,series_count)
        
        stopTime = time.time()
        slicer.util.mainWindow().statusBar().showMessage(f"Processing completed in {stopTime-startTime:.2f} seconds")

# Batch Processing
class LSProcessBatch(ScriptedLoadableModuleLogic,VTKObservationMixin):
    def __init__(self) -> None:
        """Called when the logic class is instantiated. Can be used for initializing member variables."""
        ScriptedLoadableModuleLogic.__init__(self)
    
    def getParameterNode(self):
        return DeepLSParameterNode(super().getParameterNode())
    
    def process_batch(self):

        layoutManager = slicer.app.layoutManager()
        layoutManager.setLayout(slicer.vtkMRMLLayoutNode.SlicerLayoutOneUp3DView)

        from DICOMLib import DICOMUtils

        #Get the Output directory to store the segmentation &Grading Results
        dir_button=slicer.util.findChildren(widget=None, name='DirectoryButton')
        output_directory=dir_button[0].directory
        
        #Create the Progress Bar to display the process of batch
        progressbar = slicer.util.createProgressDialog(parent=slicer.util.mainWindow(), value=0, maximum=100,windowTitle="Batch Processing Initiated. Please Wait..",autoClose=True)
        progressbar.setMinimumWidth(390)
        process_canceled=0

        db = slicer.dicomDatabase
        patients = db.patients()
        grading_results=[]
        for pindex,patientUID in enumerate(patients):
            #If progress bar is canceled exit out of this loop
            if progressbar.wasCanceled:
                process_canceled=1
                progressbar.close()
                slicer.util.mainWindow().statusBar().showMessage("Canceled by user")
                break
            
            #This loads dicom to MRML scene. We need to clear after each patient is processed
            dicomNodeID=DICOMUtils.loadPatientByUID(patientUID)
            
            #Get the volume node for a given patientUID
            volumeNode = slicer.mrmlScene.GetNodeByID(dicomNodeID[0])

            #Slicer returns unique id for patients. We need to construct the filename for identification during batch export.
            patientName= slicer.dicomDatabase.nameForPatient(patientUID)
            shNode = slicer.mrmlScene.GetSubjectHierarchyNode()
            seriesItem = shNode.GetItemByDataNode(volumeNode)
            studyItem = shNode.GetItemParent(seriesItem)
            patientItem = shNode.GetItemParent(studyItem)
            patientID = shNode.GetItemAttribute(patientItem, 'DICOM.PatientID')
            patientKey=f"{patientName}_{patientID}_{patientUID}"
            
            
            outdir=f"{output_directory}/{patientKey}"
            os.makedirs(outdir,exist_ok=True)
            outfile=f"{output_directory}/{patientKey}/{patientKey}.nrrd"

            #Set Progress Bar Info
            progressbar.labelText = f'Processing Patient: {patientID}'
            perc=round((pindex+1)*100/len(patients),0)
            slicer.app.processEvents()
            progressbar.setValue(perc)

            #Process Voxel Information For the Volume and obtain numpy array
            voxels = slicer.util.arrayFromVolume(volumeNode)  
            series_count=voxels.shape[0]
            mid_saggital=series_count//2
            du=deepUtils()
            slice = du.int16_to_uint8(voxels[mid_saggital,:,:])

            #Perform Prediction
            autoseg=autoSegment(slice)
            prediction=autoseg.predict()

            du.update_segmentation_slicer(volumeNode,prediction,mid_saggital,series_count)

            if prediction.shape[0]!=voxels.shape[1] or prediction.shape[1]!=voxels.shape[2]:
                prediction=cv2.resize(prediction,(voxels.shape[1],voxels.shape[2]), interpolation=cv2.INTER_NEAREST)


            #Perform Grading
            pfirrmann=autoGrade(slice,prediction,custom_layout='N')
            result=pfirrmann.grade()    
            result.insert(0,patientKey)
            grading_results.append(result)


            #Save the Image and Segmentation based on User Choice of exporting with dicoms
            exportCheck=slicer.util.findChildren(widget=None, name='exportCheck')
            if exportCheck[0].checked:
                slicer.util.saveNode(volumeNode, outfile)
            segmentationNode= slicer.mrmlScene.GetNodeByID('vtkMRMLSegmentationNode1')
            seg_file=outfile.replace(".nrrd",".seg.nrrd")
            slicer.util.saveNode(segmentationNode,seg_file)
            
            
            #Clear the Scene after processing
            slicer.mrmlScene.Clear()
        
        if process_canceled==0:
            import csv
            # Write the data to the CSV file
            result_file=f"{output_directory}/grade_dhi_results.csv"           
            grading_results.insert(0,['Patient Key','Pfirrmann_L1/2','Pfirrmann_L2/3','Pfirrmann_L3/4','Pfirrmann_L4/5','Pfirrmann_L5/S1','DHI_L1/2','DHI_L2/3','DHI_L3/4','DHI_L4/5','DHI_L5/S1'])
           
            with open(result_file, mode='w', newline='') as file:
                writer = csv.writer(file)
                for row in grading_results:
                    writer.writerow(row)  # Write each row
            
            slicer.util.mainWindow().statusBar().showMessage("Batch Processing Complete")


    def process(self,
                inputVolume: vtkMRMLScalarVolumeNode,
                showResult: bool = True) -> None:
        
        slicer.util.mainWindow().statusBar().showMessage("Starting Batch Processing......")
        self.process_batch()
        
#
# DeepLSTest
#


# class DeepLSTest(ScriptedLoadableModuleTest):
#     """
#     This is the test case for your scripted module.
#     Uses ScriptedLoadableModuleTest base class, available at:
#     https://github.com/Slicer/Slicer/blob/main/Base/Python/slicer/ScriptedLoadableModule.py
#     """

#     def setUp(self):
#         """Do whatever is needed to reset the state - typically a scene clear will be enough."""
#         slicer.mrmlScene.Clear()

#     def runTest(self):
#         """Run as few or as many tests as needed here."""
#         self.setUp()
#         self.test_DeepLS1()

#     def test_DeepLS1(self):
#         """Ideally you should have several levels of tests.  At the lowest level
#         tests should exercise the functionality of the logic with different inputs
#         (both valid and invalid).  At higher levels your tests should emulate the
#         way the user would interact with your code and confirm that it still works
#         the way you intended.
#         One of the most important features of the tests is that it should alert other
#         developers when their changes will have an impact on the behavior of your
#         module.  For example, if a developer removes a feature that you depend on,
#         your test should break so they know that the feature is needed.
#         """

#         self.delayDisplay("Starting the test")

#         # Get/create input data

#         import SampleData

#         registerSampleData()
#         inputVolume = SampleData.downloadSample("DeepLS1")
#         self.delayDisplay("Loaded test data set")

#         inputScalarRange = inputVolume.GetImageData().GetScalarRange()
#         self.assertEqual(inputScalarRange[0], 0)
#         self.assertEqual(inputScalarRange[1], 695)

#         outputVolume = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLScalarVolumeNode")
#         threshold = 100

#         # Test the module logic

#         logic = DeepLSLogic()

#         # Test algorithm with non-inverted threshold
#         logic.process(inputVolume, outputVolume, threshold, True)
#         outputScalarRange = outputVolume.GetImageData().GetScalarRange()
#         self.assertEqual(outputScalarRange[0], inputScalarRange[0])
#         self.assertEqual(outputScalarRange[1], threshold)

#         # Test algorithm with inverted threshold
#         logic.process(inputVolume, outputVolume, threshold, False)
#         outputScalarRange = outputVolume.GetImageData().GetScalarRange()
#         self.assertEqual(outputScalarRange[0], inputScalarRange[0])
#         self.assertEqual(outputScalarRange[1], inputScalarRange[1])

#         self.delayDisplay("Test passed")
